import pandas as pd
import matplotlib.pyplot as plt
import plotly.express as px
from dash import Dash, html, dcc

df=pd.read_csv("Sample - Superstore.csv",encoding='latin1')

df['Order Date']=pd.to_datetime(df['Order Date'])
df['Ship Date']=pd.to_datetime(df['Ship Date'])

df['Year']=df['Order Date'].dt.year
df['Month']=df['Order Date'].dt.month_name()
df['Month Name'] = df['Order Date'].dt.strftime('%b')
df['Year-Month'] = df['Order Date'].dt.to_period('M').dt.to_timestamp()

month=df.groupby(['Year','Month','Month Name'])[['Sales','Profit']].sum().reset_index()
year=df.groupby('Year')[['Sales','Profit']].sum().reset_index()

month['Month Name']=pd.Categorical(
    month['Month Name'],
    categories=['Jan','Feb','Mar','Apr','May','Jun',
                'Jul','Aug','Sep','Oct','Nov','Dec'],
    ordered=True
)
top_10_pro=df.groupby('Product Name')['Sales'].sum().sort_values(ascending=False).head(10)

top_10_cus=df.groupby('Customer Name')['Sales'].sum().sort_values(ascending=False).head(10)

profit=df['Profit'].sum()
sale=df['Sales'].sum()
gain=(profit/sale)*100

app=Dash(__name__)
app.title='Sales and Revenue Tracker'
app.layout=html.Div([
    html.H1('Sales & Revenue Tracker',style={'textAlign':'center'}),
    html.H2('Monthly Sales  '),
    dcc.Graph(
        figure=px.line(
        month.sort_values(['Year', 'Month Name']),x='Month Name',y='Sales',color='Year',markers=True,
        category_orders={'Month Name': ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
                                        'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']}
        )
    ),
    html.H2('Monthly Profit '),
    dcc.Graph(
        figure=px.line(
        month.sort_values(['Year', 'Month Name']),x='Month Name',y='Profit',color='Year',markers=True,
        category_orders={'Month Name': ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
                                        'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']}
        )
    ),
    html.H2('Yearly Sales and Profit'),
    dcc.Graph(
        figure=px.bar(year,x='Year',y=['Sales','Profit'],barmode='group')
    ),

    html.H2('Top 10 Products by Sales'),
    dcc.Graph(
        figure=px.bar(top_10_pro,x=top_10_pro.values, y=top_10_pro.index,orientation='h',labels={'x': 'Sales', 'y': 'Product Name'})
    ),

    html.H2('Top 10 Customers by Sales'),
    dcc.Graph(
        figure=px.bar(top_10_cus,x=top_10_cus.values, y=top_10_cus.index,orientation='h',labels={'x': 'Sales', 'y': 'Customer Name'})
    ),

    html.H2('Overall Profit Margin'),
    html.P(f"Total Sales: ${sale:,.2f}"),
    html.P(f"Total Profit: ${profit:,.2f}"),
    html.P(f"Profit Margin: {gain:.2f}%")
])

if __name__ =='__main__':
    app.run(debug=True)