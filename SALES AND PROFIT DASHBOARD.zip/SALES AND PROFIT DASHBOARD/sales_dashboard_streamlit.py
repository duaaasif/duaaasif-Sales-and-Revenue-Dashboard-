import streamlit as st
import pandas as pd
import plotly.express as px


df=pd.read_csv("Sample - Superstore.csv", encoding='latin1')
# Convert to datetime
df['Order Date']=pd.to_datetime(df['Order Date'])
df['Ship Date']=pd.to_datetime(df['Ship Date'])
# Extract time features
df['Year']=df['Order Date'].dt.year
df['Month']=df['Order Date'].dt.month_name()
df['Month Name']=df['Order Date'].dt.strftime('%b')
df['Year-Month']=df['Order Date'].dt.to_period('M').dt.to_timestamp()

# Monthly and yearly aggregations
month=df.groupby(['Year','Month','Month Name'])[['Sales','Profit']].sum().reset_index()
year=df.groupby('Year')[['Sales', 'Profit']].sum().reset_index()

# Fix month order
month['Month Name']=pd.Categorical(
    month['Month Name'],
    categories=['Jan','Feb','Mar','Apr','May','Jun',
                'Jul','Aug','Sep','Oct','Nov','Dec'],
    ordered=True
)
top_10_pro=df.groupby('Product Name')['Sales'].sum().sort_values(ascending=False).head(10)
top_10_cus=df.groupby('Customer Name')['Sales'].sum().sort_values(ascending=False).head(10)

profit=df['Profit'].sum()
sale=df['Sales'].sum()
gain=(profit / sale) * 100

st.set_page_config(page_title="Sales & Revenue Tracker", layout="wide")
st.title("📊 Sales & Revenue Tracker")

st.header("1️⃣ Monthly Sales")
fig_sales = px.line(
    month.sort_values(['Year', 'Month Name']),
    x='Month Name', y='Sales', color='Year', markers=True,
    category_orders={'Month Name': ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
                                    'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']}
)
st.plotly_chart(fig_sales, use_container_width=True)

st.header("2️⃣ Monthly Profit")
fig_profit = px.line(
    month.sort_values(['Year', 'Month Name']),
    x='Month Name', y='Profit', color='Year', markers=True,
    category_orders={'Month Name': ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
                                    'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']}
)
st.plotly_chart(fig_profit, use_container_width=True)

st.header("3️⃣ Yearly Sales & Profit")
fig_year = px.bar(year, x='Year', y=['Sales', 'Profit'], barmode='group')
st.plotly_chart(fig_year, use_container_width=True)

col1, col2 = st.columns(2)

with col1:
    st.header("4️⃣ Top 10 Products by Sales")
    fig_top_pro = px.bar(
        top_10_pro, x=top_10_pro.values, y=top_10_pro.index,
        orientation='h', labels={'x': 'Sales', 'y': 'Product Name'}
    )
    st.plotly_chart(fig_top_pro, use_container_width=True)

with col2:
    st.header("5️⃣ Top 10 Customers by Sales")
    fig_top_cus = px.bar(
        top_10_cus, x=top_10_cus.values, y=top_10_cus.index,
        orientation='h', labels={'x': 'Sales', 'y': 'Customer Name'}
    )
    st.plotly_chart(fig_top_cus, use_container_width=True)

st.header("6️⃣ Overall Profit Margin")
st.success(f"💰 Total Sales: ${sale:,.2f}")
st.success(f"📈 Total Profit: ${profit:,.2f}")
st.success(f"📊 Profit Margin: {gain:.2f}%")
